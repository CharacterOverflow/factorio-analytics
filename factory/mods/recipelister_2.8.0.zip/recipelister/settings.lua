require("util")

local entries = {
    "recipe",
    "item",
    "fluid",
    "assembling-machine",
    "furnace",
    "mining-drill",
    "resource",
    "transport-belt",
    "inserter",
    "boiler",
    "generator",
    "reactor",
    "solar-panel",
    "lab",
    "technology",
    "equipment",
    "equipment-grid",
    "rocket-silo",
    "projectile"
}

for _, entry in pairs(entries) do
   data:extend{{
      type = "bool-setting",
      setting_type = "runtime-per-user",
      default_value = true,
      name = "recipelister-enable-" .. entry,
      order = "a-" .. entry,
   }}
end

data:extend({
	-- runtime
	{
		type = "bool-setting",
		name = "recipelister-output",
		order = "a",
		setting_type = "runtime-per-user",
		default_value = true,
	},
	{
		type = "bool-setting",
		name = "recipelister-write-active-mods",
		order = "aa",
		setting_type = "runtime-per-user",
		default_value = true,
	},
	{
		type = "bool-setting",
		name = "recipelister-split-output",
		order = "aa",
		setting_type = "runtime-per-user",
		default_value = true,
	-- },
	-- {
		-- type = "string-setting",
		-- name = "recipelister-blacklist",
		-- order = "a",
		-- allow_blank = true,
		-- setting_type = "runtime-per-user",
		-- default_value = "",
	}
})
